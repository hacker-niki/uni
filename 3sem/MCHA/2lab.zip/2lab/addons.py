import numpy as np

from simpleIterations import simple_iterations
from zeidel import zeidel_method


def check_convergence(M: np.array) -> bool:
    return (
            np.linalg.norm(M.astype(np.float64)) < 1
            or np.linalg.norm(M.astype(np.float64), ord=1) < 1
            or np.linalg.norm(M.astype(np.float64), ord=2) < 1
            or np.linalg.norm(M.astype(np.float64), ord=np.inf) < 1
    )


def check_zeros_diag(matrix_a: np.ndarray, matrix_b: np.ndarray):
    l = len(matrix_a)
    for i in range(0, l):
        if matrix_a[i][i] == 0:
            check = True
            for j in range(0, l):
                if matrix_a[i][j] != 0 and matrix_a[j][i] != 0:
                    matrix_a[[i, j]] = matrix_a[[j, i]]
                    matrix_b[[i, j]] = matrix_b[[j, i]]
                    t = matrix_b[i]
                    matrix_b[i] = matrix_b[j]
                    matrix_b[j] = t
                    check = False
                    break
            if check:
                print("Невозможно избавиться от 0 на диагонали!")
                raise Exception('Невозможно избравиться от 0 на диагонали!')


def check(matrix_a: np.ndarray) -> bool:
    for i in range(matrix_a.shape[0]):
        sumar = 0
        for k in range(matrix_a.shape[1]):
            if k != i:
                sumar += abs(matrix_a[i, k])
        if sumar >= abs(matrix_a[i, i]):
            return False
    return True


def read_matrix_from_file(filename='a.mcha'):
    matrix = []
    with open(filename, 'r') as file:
        for line in file:
            row = list(map(float, line.split()))  # Преобразуем строку в список целых чисел
            matrix.append(row)  # Добавляем строку в матрицу
    return np.array(matrix)


def test_methods(num_tests: int = 10):
    np.random.seed(42)

    tolerance = 0.0001

    for i in range(num_tests):
        n = np.random.randint(3, 101)  # Случайное число для размерности матрицы
        a = np.random.rand(n, n)
        b = np.random.rand(n)

        # Добавляем число, равное размерности матрицы, к диагональным элементам матрицы a
        np.fill_diagonal(a, np.diagonal(a) + n)

        print(f"Тест #{i + 1}")
        # print("Матрица:")
        # print(a)
        # print("Вектор b:")
        # print(b)

        # Вычисляем решение с помощью np.linalg.solve
        expected_solution = np.linalg.solve(a, b)

        # Вычисляем решение с помощью метода простых итераций
        val = simple_iterations(a, b)
        if val:
            ans_simple, ans_simple_cnt = val

        # Вычисляем решение с помощью метода Зейделя
        val = zeidel_method(a, b)
        if val:
            ans_zeidel, ans_zeidel_cnt = zeidel_method(a, b)
        else:
            continue
        # Проверяем точность результатов
        simple_correct = True
        zeidel_correct = True

        if ans_simple is None or ans_zeidel is None:
            continue

        for j in range(len(expected_solution)):
            if abs(abs(ans_simple[j]) - abs(expected_solution[j])) > tolerance:
                simple_correct = False
            if abs(abs(ans_zeidel[j]) - abs(expected_solution[j])) > tolerance:
                zeidel_correct = False

        print(
            f"Размерность заданной матрицы - {n}\n"
            f"Методом Зейделя количество итераций {ans_zeidel_cnt}, методом простых итераций количество итераций {ans_simple_cnt}")
        if simple_correct and zeidel_correct:
            print("Все методы дали результаты с точностью 0.0001.")
        else:
            print("Один или несколько методов дали результаты с недопустимой точностью.")

        print("=============================")
