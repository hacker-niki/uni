import methods

# print(separation_of_roots.split_interval(interval=function.interval, max_roots=sturm.get_root_count()))
print(methods.solve_bisection())
print(methods.solve_hord())
print(methods.solve_newton())
